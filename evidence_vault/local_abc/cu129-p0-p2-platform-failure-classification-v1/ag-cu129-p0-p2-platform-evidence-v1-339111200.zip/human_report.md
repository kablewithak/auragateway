# AuraGateway CUDA 12.9 P0-P2 Platform Diagnostic

- Diagnostic ID: `auragateway-cu129-p0-p2-platform-diagnostic-v1`
- Source main merge: `f4f08eda4b4d4747514b4646fe53664d8a78ca6d`
- Overall status: `FAILED_CLOSED`
- Terminal decision: `CURRENT_KAGGLE_IMAGE_LINKER_CONTRACT_FAILED`

## Probe results

- P0 — PASSED — `PLATFORM_IDENTITY_CAPTURED`
- P1 — FAILED — `CURRENT_KAGGLE_IMAGE_LINKER_CONTRACT_FAILED`
- P2 — NOT_RUN_DUE_TO_PRIOR_FAILURE — `CURRENT_KAGGLE_IMAGE_LINKER_CONTRACT_FAILED`

## Safety

- Model loads: 0
- Worker starts: 0
- Model requests: 0
- Benchmark trajectory requests: 0
- Network requests: 0
- Customer data: absent
- External spend: 0

## Non-claims

This diagnostic does not prove model serving, explicit TRITON_ATTN worker startup, inference, prefix-cache telemetry, reset behavior, dual-worker readiness, measured A/B/C effects, deployment, or production readiness.
