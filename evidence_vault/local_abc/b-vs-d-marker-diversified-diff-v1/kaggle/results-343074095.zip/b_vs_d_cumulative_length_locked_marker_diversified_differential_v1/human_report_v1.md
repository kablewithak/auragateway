# AuraGateway B-vs-D Marker-Diversified Differential V1

- Status: DIAGNOSTIC_COMPLETE
- Decision: MARKER_DIVERSIFICATION_RESTORES_BEHAVIOR_UNDER_CUMULATIVE_LENGTH_LOCK
- Completed requests: 6 / 6
- Worker starts: 6 / 6
- Model loads: 6 / 6
- Worker teardown: PASSED
- Scratch cleanup: PASSED
- Conditions: B repeated failure anchor, D marker-diversified intervention
- Prompt tokens per condition: 899
- Fresh worker process per observation: true
- Cache telemetry is diagnostic only.
- Raw prompts retained: false
- Raw model outputs retained: false
- Hidden retries: 0
- Replacement observations: 0
- P5/P6 were not requalified by this diagnostic.
- No measured North-Star A/B/C benchmark trajectory was executed.
- Production readiness is not claimed.
