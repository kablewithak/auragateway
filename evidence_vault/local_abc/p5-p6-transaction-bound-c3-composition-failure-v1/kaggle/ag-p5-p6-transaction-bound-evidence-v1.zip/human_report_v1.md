# AuraGateway Exact-Runtime P5/P6 Requalification V2

- Status: FAILED
- Terminal state: FAILED_PENDING_REPOSITORY_DISPOSITION
- P5 decision: None
- P6 decision: None
- Worker teardown: PASSED
- Completed capabilities: C1, C2
- Model requests: 1 / 6 maximum
- Hidden retries: 0
- No A/B/C benchmark trajectory was executed.
- Pilot and final measured A/B/C remain unauthorized.
- Production readiness is not claimed.
